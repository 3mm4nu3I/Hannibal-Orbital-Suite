# Zombie check (`hannibal_zombie.py`) -- added 22 Oct 2026

Local copy for this folder (Desktop\hannibal_orbital_directorate). The same work is on GitHub as
pull request #9 (branch `orbital/zombie-check`) and in Google Drive under
`hannibal_orbital_directorate\2026-10-22_zombie-check`.

## What it answers

The Home window and the 17 Oct satellite detail export (`overhead_antwerp.txt`) tell you **where** the
military satellites over Antwerp are. They cannot tell you whether anything on them still works: N2YO
computes positions from orbital elements, so a satellite that went dark in 1966 sits in the list exactly
like one launched last year. This module asks the one thing that can tell them apart: reception. Has
anyone actually heard it?

## What changed in this folder

Only new files were added, plus ERS 15 on the watch list (see below).

| File | What |
|---|---|
| `hannibal_zombie.py` | the check (standalone; uses your `hannibal_net.py` for caching, throttling and masking) |
| `zombie_targets_2026-10-17.json` | the 148 military NORAD ids and names from the 17 Oct export (default list) |
| `test_hannibal_zombie.py` | offline tests, no network |
| `CHANGELOG_zombie-check_2026-10-22.md` | this file |

Tested against this folder's own `hannibal_net.py` (the one with the 16 Oct home-location fix): tests
pass and a live run gives the same result as below.

## ERS 15 on the watch list (added later the same evening)

ERS 15 (NORAD 2412) is now in `norad_targets.json`, this folder's fleet list, so every fleet telemetry scan
(`[1]`, `[L]`, `python run_telemetry.py`, `--scan`) checks it alongside the ISS, FUNcube-1 and the rest. It is
the only change to an existing file in this folder; the previous version is saved next to it as
`norad_targets.json.pre-ers15.bak`.

First scan, 24 h window: `UNVETTED` (one observation from this morning is still waiting to be reviewed).
Over 30 days: 2 good, 5 bad, 15 still unreviewed, 5 station failures: `LOW SAMPLE`, 29% (95% range 8-64%).
Expect `NO PASSES` or `UNVETTED` on most 24 h scans: it is only heard now and then. For the 30-day view:

```
python hannibal_zombie.py --ids 2412
```

## Run it

```
python hannibal_zombie.py                      the 148 military objects over Antwerp, 17 Oct 2026
python hannibal_zombie.py --above              what N2YO lists as military overhead right now (your N2YO key)
python hannibal_zombie.py --ids 2412,39483 --days 60 --json out.json
python hannibal_zombie.py --all                also list every object with nothing on record
python test_hannibal_zombie.py                 -> PASS: hannibal_zombie (...)
```

No key needed (except `--above`). Receive-only. The SatNOGS database is cached 24 h and observations 1 h
in `hannibal_cache\`. A cold run takes about 12 seconds; a cached one is instant.

## How it decides, per satellite

| Tier | Means |
|---|---|
| `HEARD` | a SatNOGS volunteer ground station logged a vetted "good" observation of it in the window (a carrier on the waterfall or decoded telemetry) |
| `LISTED, NOT HEARD` | an active transmitter is on record, but nothing good in the window (or nobody scheduled a pass) |
| `NO ACTIVE TX` | on record, but every known transmitter is marked inactive |
| `NOT IN SATNOGS` | no transmitter of this object is known to the amateur network |
| `NOT CHECKED` | the network could not be asked; the verdict then says "at least" and never claims a clean zero |

`UPLINK` says whether any transmitter on record has an uplink (a Transceiver or Transponder). Hearing a
satellite is one thing; sending it something is another, and a relay needs the second.

## Result, 22 Oct 2026 (~18:40 UTC, last 30 days)

**2 of 148 heard. 0 with an uplink on record.**

- COSMOS 2488 (39483, launched 2013): 9 good observations, last 21 Oct 12:45 UTC, UHF FM 388.687 MHz.
- ERS 15 (2412, launched 1966): 2 good, 5 bad, last 26 Sep 12:40 UTC, a CW carrier at 136.439 MHz.
  The one real 1960s survivor on the list, and it is a carrier tone, not a transponder.
- LISTED, NOT HEARD: USA 184, YAOGAN 10, YAOGAN 12. NO ACTIVE TX: USA 198 (SDS-3 F-5).
- NOT IN SATNOGS: the other 142.

## Limits

- SatNOGS only knows transmitters amateurs have found and logged. "Not in SatNOGS" is not proof a
  satellite is dead: military links on bands amateurs don't monitor (or encrypted) never show up here.
  For the question "is there anything here an amateur station can use", that does not change the answer.
- "Heard" is evidence of a working transmitter, not of a link anyone can command.

## Update, 23 Oct 2026: synced with GitHub

This folder now matches GitHub's main branch (pull requests #9 and #10). `[Z] Zombie check` is in the
Orbital Ops menu, alongside `[W] Where it won't be`, `[D] Debris cascade` and your `[E] Moonbounce`, and
`python hannibal_orbital.py --zombie` works. The files that were replaced are kept in
`_backup_2026-10-23_pre-sync`. The main `CHANGELOG.md` has the full record.
