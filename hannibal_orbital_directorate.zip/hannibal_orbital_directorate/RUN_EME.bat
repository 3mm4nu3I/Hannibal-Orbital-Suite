@echo off
REM One-shot: Hannibal EME (moonbounce) link budget for the saved home (Antwerp).
REM Read-only: pulls the Moon from Horizons, computes, writes eme_antwerp.txt. Changes nothing.
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY where python >nul 2>&1 && set "PY=python"
echo Running Hannibal EME (23cm / 3m / 300W / Tsys 100K) ... output: eme_antwerp.txt
echo RUN %date% %time% > eme_antwerp.txt
(echo 23cm^&echo 3^&echo 300^&echo 100) | %PY% hannibal_orbital.py --eme --no-anim --no-login >> eme_antwerp.txt 2>&1
echo. >> eme_antwerp.txt
echo ===== self-tests ===== >> eme_antwerp.txt
%PY% test_hannibal_eme.py >> eme_antwerp.txt 2>&1
echo DONE >> eme_antwerp.txt
echo Done. You can close this window.
timeout /t 5 >nul
