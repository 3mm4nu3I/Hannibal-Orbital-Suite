
def get_distribution(package):
    class Dist:
        version = "0.2.9"
    return Dist()

def resource_filename(package_or_requirement, resource_name):
    import os
    return os.path.join(os.path.dirname(__file__), resource_name)

class WorkingSet:
    def find(self, req):
        return None
def iter_entry_points(group, name=None):
    return []

