@echo off
REM One-shot: Hannibal Orbital "overhead now" for the saved home (~/.hannibal/home.json = Antwerp).
REM Writes everything to overhead_antwerp.txt next to this file. Read-only: changes nothing.
chcp 65001 >nul
cd /d "%~dp0"
set "PYTHONUTF8=1"
set "HANNIBAL_NET_PROFILE=normal"
set "PY="
where py >nul 2>&1 && set "PY=py -3"
if not defined PY where python >nul 2>&1 && set "PY=python"
echo Running Hannibal orbital --home ... output: overhead_antwerp.txt
echo RUN %date% %time% > overhead_antwerp.txt
%PY% hannibal_orbital.py --home --no-anim --no-login >> overhead_antwerp.txt 2>&1
echo. >> overhead_antwerp.txt
echo ===== FULL MILITARY LIST (same module, served from its 5-minute cache) ===== >> overhead_antwerp.txt
%PY% -c "import hannibal_orbital as h; h._install_masking(); h._above_table(h.get_above(h.MILITARY), print, False, limit=500, numbered=True)" >> overhead_antwerp.txt 2>&1
echo DONE >> overhead_antwerp.txt
echo Done. You can close this window.
timeout /t 5 >nul
