"""Hannibal orbital telemetry engine.

One engine, two ways to use it:

  * standalone:   python run_telemetry.py        (prints a table, writes telemetry_report.json)
  * imported:     import run_telemetry           (hannibal_terminal.py's [L] view does this)

Importing this module has NO side effects: it does not install packages, wrap
stdout, or touch the network. All of that happens only inside main().

Data sources
  * SatNOGS Network  - recent ground-station observations -> "packet health"
  * Space-Track      - latest TLE epoch (optional; needs a free account; rate-limit safe + cached)

Space-Track credentials come from the SPACETRACK_USER / SPACETRACK_PASS
environment variables first, then from norad_targets.json (unless the file
still holds the YOUR_... placeholders).
"""
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:  # shared redaction primitives; degrade to pass-through if the file is missing
    from secret_masking import redact, redact_text
except ImportError:  # pragma: no cover
    def redact_text(value):
        return str(value)

    def redact(value):
        return value

FROZEN = getattr(sys, "frozen", False)
TARGETS_FILE = "norad_targets.json"
REPORT_FILE = "telemetry_report.json"
SATNOGS_URL = "https://network.satnogs.org/api/observations/"
HEADERS = {"User-Agent": "Hannibal-Telemetry/2.0"}
MAX_PAGES = 6          # SatNOGS pages are small (25); cap so one satellite can't stall a scan
HTTP_TIMEOUT = 15

# Verified in-orbit on 2026-10-01 against the SatNOGS DB. Used only when
# norad_targets.json is missing or unreadable.
DEFAULT_FLEET = [
    {"id": 25544, "name": "ISS (ZARYA)", "type": "Amateur Radio / Habited"},
    {"id": 39444, "name": "FUNcube-1 (AO-73)", "type": "Amateur Radio / Education"},
    {"id": 39161, "name": "ESTCube-1", "type": "Educational / Estonian CubeSat"},
    {"id": 40931, "name": "LAPAN-A2 (ORARI / IO-86)", "type": "Amateur Radio / Equatorial"},
    {"id": 40069, "name": "METEOR M-2", "type": "Weather / LRPT"},
    {"id": 7530, "name": "OSCAR 7 (AO-7)", "type": "Amateur Radio / Linear Transponder"},
    {"id": 24278, "name": "JAS-2 (FO-29)", "type": "Amateur Radio / Linear Transponder"},
]


# ---------------------------------------------------------------- paths ----
from hannibal_net import base_dir, resource_path  # noqa: E402  (single definition shared by every module)


def report_path():
    return base_dir() / REPORT_FILE


# --------------------------------------------------------------- config ----
def load_config():
    cfg = {"satnogs": {"lookback_hours": 24}, "targets": list(DEFAULT_FLEET), "space_track_auth": {}}
    path = resource_path(TARGETS_FILE)
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except FileNotFoundError:
        return cfg
    except (OSError, ValueError) as exc:
        print(f"[!] Could not read {path.name}: {redact_text(exc)} -- using built-in fleet.")
        return cfg

    targets = []
    for entry in data.get("targets", []) if isinstance(data, dict) else []:
        try:
            targets.append({"id": int(entry["id"]), "name": str(entry["name"]),
                            "type": str(entry.get("type", ""))})
        except (KeyError, TypeError, ValueError):
            continue  # skip malformed rows instead of crashing the scan
    if targets:
        cfg["targets"] = targets
    try:
        hours = float(data.get("satnogs", {}).get("lookback_hours", 24))
        if hours > 0:
            cfg["satnogs"]["lookback_hours"] = hours
    except (TypeError, ValueError):
        pass
    auth = data.get("space_track_auth")
    if isinstance(auth, dict):
        cfg["space_track_auth"] = auth
    return cfg


def get_credentials(cfg):
    """env vars, then credentials typed at start-up, then norad_targets.json (placeholders ignored)."""
    from hannibal_spacetrack import get_credentials as _creds
    return _creds(cfg.get("space_track_auth", {}))


# -------------------------------------------------------------- fetching ----
def _requests():
    import requests  # imported lazily so merely importing this module can never fail
    return requests


def fetch_satnogs(session, norad_id, hours_back):
    """Return (observations, error). `error` is None on success.

    A network/API failure returns ([], "message") so it can be told apart from
    a satellite that genuinely had no passes.
    """
    requests = _requests()
    now = datetime.now(timezone.utc)
    start = now - timedelta(hours=hours_back)
    params = {
        "norad_cat_id": norad_id,
        "start": start.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "end": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "format": "json",
    }
    url, observations = SATNOGS_URL, []
    try:
        for _ in range(MAX_PAGES):
            res = session.get(url, params=params, headers=HEADERS, timeout=HTTP_TIMEOUT)
            res.raise_for_status()
            page = res.json()
            if not isinstance(page, list):
                return [], "unexpected SatNOGS response shape"
            observations.extend(page)
            nxt = res.links.get("next", {}).get("url")
            if not nxt:
                break
            url, params = nxt, None  # the next-link already carries the query string
        return observations, None
    except (requests.RequestException, ValueError) as exc:
        return observations, redact_text(exc)


def fetch_spacetrack_epochs(session, user, password, norad_ids):
    """Return (epochs, error, note).

    Goes through hannibal_spacetrack, which enforces Space-Track's published limits
    (GP: one live query per hour, <30 req/min, <300 req/h) and serves cached element
    sets in between. `session` is accepted for backwards compatibility and unused: the
    shared hannibal_net layer owns the connection. `note` says when cached data was used.
    """
    from hannibal_spacetrack import SpaceTrack
    client = SpaceTrack(user=user, password=password)
    epochs, info = client.gp_epochs(norad_ids)
    if not epochs and info:
        return {}, redact_text(info), ""
    return epochs, None, info or ""


# ---------------------------------------------------------- classification ----
def summarize(observations):
    """SatNOGS `status` is lowercase: good / bad / failed / unknown / future.

    Only completed, vetted observations (good, bad, failed) count toward packet
    health. 'future' = scheduled, 'unknown' = awaiting vetting.
    """
    states = [str(o.get("status", "")).lower() for o in observations]
    good = states.count("good")
    done = good + states.count("bad") + states.count("failed")
    unvetted = states.count("unknown")
    return good, done, unvetted


def classify(good, done, unvetted):
    if done == 0:
        return "UNVETTED" if unvetted else "NO PASSES"
    pct = good / done * 100
    if pct >= 75:
        return "ONLINE"
    if pct >= 25:
        return "INTERMITTENT"
    return "OFFLINE"


def format_epoch(raw):
    return raw.split(".")[0].replace("T", " ") if raw else "N/A"


# --------------------------------------------------------------------- scan ----
def scan(progress=None):
    """Run a full scan. Returns (rows, meta).

    rows: list of dicts in the telemetry_report.json schema (what the dashboard reads).
    meta: {"errors": int, "spacetrack": str, "hours": float}
    progress: optional callable(done_count, total, row).
    """
    requests = _requests()
    cfg = load_config()
    targets = cfg["targets"]
    hours = cfg["satnogs"]["lookback_hours"]
    user, password = get_credentials(cfg)

    rows, errors = [], 0
    with requests.Session() as session:
        if user:
            epochs, st_err, st_note = fetch_spacetrack_epochs(session, user, password, [t["id"] for t in targets])
            st_state = "ok" if st_err is None else st_err
        else:
            epochs, st_state, st_note = {}, "no credentials", ""

        for index, target in enumerate(targets, 1):
            observations, err = fetch_satnogs(session, target["id"], hours)
            good, done, unvetted = summarize(observations)
            if err:
                errors += 1
                status, health = "LINK ERROR", "N/A (fetch failed)"
            else:
                status = classify(good, done, unvetted)
                health = f"{good / done * 100:.1f}% ({done} rx)" if done else "N/A (0 rx)"
            if epochs.get(target["id"]):
                epoch = format_epoch(epochs[target["id"]])
            else:
                epoch = "N/A (No Auth)" if st_state == "no credentials" else "N/A"
            row = {"NORAD ID": target["id"], "Target Name": target["name"], "TLE Epoch": epoch,
                   "Status": status, "Packet Health": health}
            rows.append(row)
            if progress:
                progress(index, len(targets), row)
    return rows, {"errors": errors, "spacetrack": st_state, "spacetrack_note": st_note, "hours": hours}


# ------------------------------------------------------------------- report ----
def write_report(rows, meta=None):
    """Atomically write telemetry_report.json. Returns True if written.

    If EVERY satellite failed to fetch (offline machine, SatNOGS down), the
    previous report is kept instead of being overwritten with error rows.
    """
    if rows and meta and meta.get("errors", 0) >= len(rows):
        return False
    path = report_path()
    tmp = path.with_name(path.name + ".tmp")
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(redact(rows), fh, indent=2)
    os.replace(tmp, path)
    return True


def load_cached_report():
    """Return (rows, age_seconds). ([], None) if there is no readable report."""
    path = report_path()
    try:
        age = max(0.0, time.time() - path.stat().st_mtime)
        with open(path, "r", encoding="utf-8") as fh:
            rows = json.load(fh)
        return (rows if isinstance(rows, list) else []), age
    except (OSError, ValueError):
        return [], None


def format_table(rows):
    cols = ["NORAD ID", "Target Name", "TLE Epoch", "Status", "Packet Health"]
    cells = [[str(r.get(c, "")) for c in cols] for r in rows]
    widths = [max(len(c), *(len(row[i]) for row in cells)) if cells else len(c) for i, c in enumerate(cols)]
    line = lambda vals: " | ".join(v.ljust(w) for v, w in zip(vals, widths))
    out = [line(cols), "-+-".join("-" * w for w in widths)]
    out += [line(row) for row in cells]
    return "\n".join(out)


# --------------------------------------------------------------------- CLI ----
def ensure_dependencies():
    """Auto-install `requests` -- only when running from source, never from a frozen .exe
    (where sys.executable is the app itself and 'pip' would relaunch it)."""
    if FROZEN:
        return
    try:
        import requests  # noqa: F401
    except ImportError:
        print("[*] Auto-installing missing package: requests ...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "--quiet"])


def main():
    ensure_dependencies()
    try:  # process-wide output redaction for standalone runs
        import hannibal_security_bootstrap  # noqa: F401
    except ImportError:
        pass

    print("[*] Hannibal Telemetry Engine Online (redaction active).")
    cfg = load_config()
    print(f"[*] Scanning {len(cfg['targets'])} targets over a {cfg['satnogs']['lookback_hours']:g}h window...\n")
    rows, meta = scan(progress=lambda i, n, r: print(f"    [{i}/{n}] {r['Target Name']}: {r['Status']}"))
    print("\n" + format_table(rows) + "\n")
    note = f" ({meta['spacetrack_note']})" if meta.get("spacetrack_note") else ""
    print(f"[*] Space-Track: {meta['spacetrack']}{note}")
    if write_report(rows, meta):
        print(f"[+] Sanitized telemetry report written to {report_path()}")
        return 0
    print("[!] Every SatNOGS request failed (offline?). Existing report left untouched.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
