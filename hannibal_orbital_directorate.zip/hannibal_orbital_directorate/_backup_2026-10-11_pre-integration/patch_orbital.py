#!/usr/bin/env python3
"""
patch_orbital.py — three fixes for the Hannibal orbital modules.

Dry run by default. Nothing is written until you pass --apply.

    python patch_orbital.py                  # show what would change
    python patch_orbital.py --apply          # patches 1 and 2
    python patch_orbital.py --apply --all    # also patch 3
    python patch_orbital.py --revert         # restore from .bak

PATCH 1 — JSON-shaped secrets reach stdout unmasked   (secret_masking.py)
    redact_text() catches  apiKey=X,  Authorization: Bearer X,  ?apiKey=X
    but NOT               {"apiKey": "X"}, {"token": "X"}, {"password": "X"}

    The dict form redact() does catch those, so cache files were never at
    risk. The gap is anything already serialised to a string before it
    reaches print, a log line or an exception — and since
    hannibal_security_bootstrap wraps stdout with redact_text, that is the
    path that leaks. Adds one pattern for the "key": "value" shape.

PATCH 2 — home coordinates hardcoded                  (hannibal_net.py,
                                                       hannibal_blueglobe.py)
    Both files default to 41.149641, -8.611235 — roughly metre precision,
    labelled "Porto Station". That is served to the browser over
    /config.json and travels with the repository. Defaults become 0.0 and
    "Home Station"; HANNIBAL_HOME_LAT / _LON / _NAME still override exactly
    as before, so nothing changes for you once they are set.

    Set them first, or the sky and pass features compute from (0, 0):
        setx HANNIBAL_HOME_LAT 41.149641          (Windows, new shell after)
        export HANNIBAL_HOME_LAT=41.149641        (bash/zsh)

PATCH 3 — RateLimiter sleeps holding the lock         (hannibal_net.py)  --all
    acquire() sleeps inside `with self._lock`, so every thread queued on
    that host is serialised behind the sleeper and can wait far longer than
    the max_wait it passed in. Computes the delay under the lock, sleeps
    outside it, then re-checks. Opt-in because it changes threading
    behaviour; harmless single-threaded.
"""

from __future__ import annotations

import argparse
import ast
import shutil
import sys
from pathlib import Path

# ---------------------------------------------------------------- patch 1
MASK_ANCHOR = """    (re.compile(r'(?i)\\b(api[_-]?key|token|secret|password|passwd)\\s*=\\s*[^\\s,;]+'), lambda m: m.group(1) + '=************'),
]"""

MASK_NEW = """    (re.compile(r'(?i)\\b(api[_-]?key|token|secret|password|passwd)\\s*=\\s*[^\\s,;]+'), lambda m: m.group(1) + '=************'),
    # JSON-shaped pairs: {"apiKey": "..."} / {"token": "..."}. redact() handles
    # dicts, but anything already serialised to a string reaches print(), a log
    # line or an exception as text, and redact_text() is what wraps stdout.
    (re.compile(r'(?i)("(?:api[_-]?key|token|secret|password|passwd|access[_-]?token'
                r'|client[_-]?secret|credential|authorization)"\\s*:\\s*)"[^"]*"'),
     lambda m: m.group(1) + '"************"'),
]"""

# ---------------------------------------------------------------- patch 2
HOME_ANCHOR = '''    return {"lat": _f("HANNIBAL_HOME_LAT", 41.149641), "lon": _f("HANNIBAL_HOME_LON", -8.611235),
            "alt_km": _f("HANNIBAL_HOME_ALT_KM", 0.1), "name": os.getenv("HANNIBAL_HOME_NAME", "Porto Station")}'''

HOME_NEW = '''    # No real coordinates in source: this file travels with the repository.
    # Set HANNIBAL_HOME_LAT / _LON / _NAME for the sky and pass features.
    return {"lat": _f("HANNIBAL_HOME_LAT", 0.0), "lon": _f("HANNIBAL_HOME_LON", 0.0),
            "alt_km": _f("HANNIBAL_HOME_ALT_KM", 0.1), "name": os.getenv("HANNIBAL_HOME_NAME", "Home Station")}'''

GLOBE_ANCHOR = '''        "home": {"lat": _float("HANNIBAL_HOME_LAT", 41.149641),
                 "lon": _float("HANNIBAL_HOME_LON", -8.611235),
                 "name": os.getenv("HANNIBAL_HOME_NAME", "Porto Station")},'''

GLOBE_NEW = '''        # No real coordinates in source: this payload is served to the browser.
        "home": {"lat": _float("HANNIBAL_HOME_LAT", 0.0),
                 "lon": _float("HANNIBAL_HOME_LON", 0.0),
                 "name": os.getenv("HANNIBAL_HOME_NAME", "Home Station")},'''

# ---------------------------------------------------------------- patch 3
LIMITER_ANCHOR = '''    def acquire(self, max_wait=60.0):
        with self._lock:
            while True:
                now = self._clock()
                while self._calls and now - self._calls[0] >= 3600.0:
                    self._calls.popleft()
                delay = self._delay(now)
                if delay <= 1e-6:   # float noise must not turn into a zero-length sleep loop
                    self._calls.append(now)
                    self._last = now
                    return
                if delay > max_wait:
                    raise RateLimitExceeded(f"rate limit reached; next call allowed in {int(delay)} s")
                self._sleep(delay)'''

LIMITER_NEW = '''    def acquire(self, max_wait=60.0):
        """Compute the delay under the lock, sleep OUTSIDE it, then re-check.

        Sleeping while holding the lock serialised every thread queued on this
        host behind the sleeper, so a caller could wait far longer than the
        max_wait it passed in. Releasing the lock first means waiters are only
        blocked for the arithmetic. The slot is still claimed under the lock,
        so the window accounting stays exact.
        """
        deadline = self._clock() + max_wait
        while True:
            with self._lock:
                now = self._clock()
                while self._calls and now - self._calls[0] >= 3600.0:
                    self._calls.popleft()
                delay = self._delay(now)
                if delay <= 1e-6:   # float noise must not turn into a zero-length sleep loop
                    self._calls.append(now)
                    self._last = now
                    return
                if delay > max_wait:
                    raise RateLimitExceeded(f"rate limit reached; next call allowed in {int(delay)} s")
            if self._clock() >= deadline:
                raise RateLimitExceeded("rate limit reached; gave up waiting for a slot")
            self._sleep(min(delay, 0.5))   # short naps: re-check rather than oversleep a freed slot'''


PATCHES = {
    "secret_masking.py": [
        ("JSON-shaped secret masking", MASK_ANCHOR, MASK_NEW, False),
    ],
    "hannibal_net.py": [
        ("home coordinates out of source", HOME_ANCHOR, HOME_NEW, False),
        ("rate limiter sleeps outside the lock", LIMITER_ANCHOR, LIMITER_NEW, True),
    ],
    "hannibal_blueglobe.py": [
        ("home coordinates out of /config.json", GLOBE_ANCHOR, GLOBE_NEW, False),
    ],
}


def apply_to(path: Path, name: str, include_optional: bool, write: bool):
    original = path.read_text(encoding="utf-8")
    text = original
    notes: list[str] = []
    count = 0

    for label, anchor, replacement, optional in PATCHES[name]:
        if optional and not include_optional:
            notes.append(f"  {label}: skipped (pass --all)")
            continue
        if replacement.split("\n")[1][:40] in text and anchor not in text:
            notes.append(f"  {label}: already applied")
            continue
        if anchor not in text:
            notes.append(f"  {label}: ANCHOR NOT FOUND — file differs from the reviewed copy")
            continue
        text = text.replace(anchor, replacement, 1)
        notes.append(f"  {label}: patched")
        count += 1

    if write and text != original:
        backup = path.with_suffix(path.suffix + ".bak")
        if not backup.exists():
            shutil.copy2(path, backup)
            notes.append(f"  backup written to {backup.name}")
        else:
            notes.append(f"  backup {backup.name} already exists, kept")
        path.write_text(text, encoding="utf-8")

    return count, notes


def verify(path: Path) -> list[str]:
    problems = []
    text = path.read_text(encoding="utf-8")
    try:
        ast.parse(text)
    except SyntaxError as exc:
        return [f"  SYNTAX ERROR line {exc.lineno}: {exc.msg}"]
    if "41.149641" in text or "-8.611235" in text:
        problems.append("  real coordinates still present")
    return problems


def self_check(root: Path) -> int:
    """Import the patched masker and confirm the JSON shapes are now covered."""
    sys.path.insert(0, str(root))
    for module in ("secret_masking",):
        sys.modules.pop(module, None)
    try:
        from secret_masking import redact_text
    except ImportError as exc:
        print(f"[-] could not import secret_masking: {exc}")
        return 1

    cases = [
        ('{"apiKey": "SEKRET123456"}', False),
        ('{"token": "SEKRET123456"}', False),
        ('{"password": "SEKRET123456"}', False),
        ('{"access_token": "SEKRET123456"}', False),
        ("api_key=SEKRET123456", False),
        ("?apiKey=SEKRET123456", False),
        ("Authorization: Bearer SEKRET123456", False),
        ('{"home": {"lat": 41.1}, "name": "Porto"}', True),   # must survive untouched
    ]
    failed = 0
    print("\nmasking self-check")
    for text, should_pass_through in cases:
        out = redact_text(text)
        leaked = "SEKRET" in out
        ok = leaked if should_pass_through else not leaked
        if should_pass_through:
            ok = out == text
        print(f"  [{'PASS' if ok else 'FAIL'}] {text[:44]:46s} -> {out[:44]}")
        if not ok:
            failed += 1
    print("  all masking cases pass" if not failed else f"  {failed} case(s) FAILED")
    return 1 if failed else 0


def revert(root: Path) -> int:
    restored = 0
    for name in PATCHES:
        backup = (root / name).with_suffix(Path(name).suffix + ".bak")
        if backup.exists():
            shutil.copy2(backup, root / name)
            print(f"[+] restored {name} from {backup.name}")
            restored += 1
    if not restored:
        print("[-] no .bak files found")
    return 0 if restored else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--dir", default=".", help="folder holding the orbital modules")
    parser.add_argument("--apply", action="store_true", help="write changes (default is dry run)")
    parser.add_argument("--all", action="store_true", help="also apply patch 3 (rate limiter)")
    parser.add_argument("--revert", action="store_true", help="restore every .bak")
    args = parser.parse_args()

    root = Path(args.dir).resolve()
    if args.revert:
        return revert(root)

    present = [n for n in PATCHES if (root / n).exists()]
    if not present:
        print(f"[-] none of {', '.join(PATCHES)} found in {root}")
        return 1

    print(f"{'APPLYING' if args.apply else 'DRY RUN — nothing will be written'}\n{root}\n")
    total = 0
    for name in present:
        path = root / name
        print(name)
        count, notes = apply_to(path, name, args.all, args.apply)
        for note in notes:
            print(note)
        total += count
        if args.apply and count:
            for problem in verify(path):
                print(problem)
        print()

    for missing in [n for n in PATCHES if n not in present]:
        print(f"{missing}\n  not in this folder, skipped\n")

    if not args.apply:
        print(f"{total} change(s) staged. Re-run with --apply to write them.")
        if not args.all:
            print("Add --all to also fix the rate limiter's lock behaviour.")
        return 0

    print(f"{total} change(s) written. Originals kept as .bak — `--revert` restores them.")
    rc = self_check(root) if (root / "secret_masking.py").exists() else 0
    print("\nSet your location before the next run, or the sky view computes from (0, 0):")
    print("  Windows:  setx HANNIBAL_HOME_LAT 41.149641")
    print("            setx HANNIBAL_HOME_LON -8.611235")
    print("            setx HANNIBAL_HOME_NAME \"Porto Station\"     (new shell to pick them up)")
    print("  bash:     export HANNIBAL_HOME_LAT=41.149641 HANNIBAL_HOME_LON=-8.611235")
    return rc


if __name__ == "__main__":
    sys.exit(main())
