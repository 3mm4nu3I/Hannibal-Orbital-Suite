# fix_interceptor_imports.py
from pathlib import Path

p = Path("hannibal_interceptor.py")
text = p.read_text(encoding="utf-8")

old_top = """from rtlsdr import RtlSdr
from skyfield.api import load, EarthSatellite, wgs84"""

old_init = """    def __init__(self, tle_line1, tle_line2, nominal_freq):
        # 1. HARDWARE: RTL-SDR Init"""

new_init = """    def __init__(self, tle_line1, tle_line2, nominal_freq):
        from rtlsdr import RtlSdr
        from skyfield.api import load, EarthSatellite, wgs84
        # 1. HARDWARE: RTL-SDR Init"""

if old_top in text and old_init in text:
    text = text.replace(old_top + "\n", "").replace(old_init, new_init, 1)
    p.write_text(text, encoding="utf-8")
    print("[+] Moved hardware imports into __init__. Restart hannibal_orbital.py now.")
else:
    print("[!] Already updated or anchor mismatch.")