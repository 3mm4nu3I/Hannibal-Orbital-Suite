
import os, urllib.request, zipfile, io, shutil

url = "https://github.com/rtlsdrblog/rtl-sdr-blog/releases/latest/download/Release.zip"
target_dir = os.path.dirname(os.path.abspath(__file__))

print("Downloading official RTL-SDR x64 binaries...")
try:
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req) as resp, zipfile.ZipFile(io.BytesIO(resp.read())) as zf:
        for name in zf.namelist():
            if "x64/" in name and name.endswith(".dll"):
                fn = os.path.basename(name)
                if fn:
                    with open(os.path.join(target_dir, fn), "wb") as fo, zf.open(name) as fi:
                        fo.write(fi.read())
                    print(f"Extracted: {fn}")
                    
    rtlsdr_path = os.path.join(target_dir, "rtlsdr.dll")
    lib_path = os.path.join(target_dir, "librtlsdr.dll")
    if os.path.exists(rtlsdr_path) and not os.path.exists(lib_path):
        shutil.copy(rtlsdr_path, lib_path)
        print("Created librtlsdr.dll alias successfully.")
    print("DLL setup complete!")
except Exception as e:
    print(f"Error: {e}")

