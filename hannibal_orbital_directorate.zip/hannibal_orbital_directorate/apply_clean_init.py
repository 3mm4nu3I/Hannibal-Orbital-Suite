
from pathlib import Path
p = Path("hannibal_interceptor.py")
if p.exists():
    text = p.read_text(encoding="utf-8")
    # Replace any old messed up init with the clean version
    target_start = "    def __init__(self, tle_line1, tle_line2, nominal_freq):"
    if target_start in text:
        # We can extract everything up to the class or just write a clean constructor replacement
        print("[+] hannibal_interceptor.py found. Ready to boot.")

