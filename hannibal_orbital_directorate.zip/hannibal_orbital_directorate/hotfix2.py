import os
import urllib.request
import zipfile
import io

url = "https://github.com/librtlsdr/librtlsdr/releases/download/v2.0.2/rtl-sdr-v2.0.2-win64.zip"
target_dir = os.path.dirname(os.path.abspath(__file__))

print(f"Downloading official RTL-SDR binaries from GitHub...")
try:
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req) as resp:
        data = resp.read()
    
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        for name in zf.namelist():
            if ".dll" in name.lower():
                filename = os.path.basename(name)
                if filename:
                    dest = os.path.join(target_dir, filename)
                    with open(dest, "wb") as f_out, zf.open(name) as f_in:
                        f_out.write(f_in.read())
                    print(f"[+] Successfully extracted {filename} to {target_dir}")
    print("[+] Done! The RTL-SDR binaries are now installed locally.")
except Exception as e:
    print(f"[-] Error: {e}")