# Mission report and debrief, 22–23 October 2026

`Project_Hannibal_Mission_Report_2026-10-23.pdf` (in this folder, 9 pages) is the report of the two days: timeline with
worked intervals, method, results (2 of 148 heard, 0 with an uplink), ERS 15's profile and reception history, the
Apophis exclusion, the moonbounce planner, a Voyager 1 link budget calibrated against JPL's design table, the Belgian
receive-only rules, next steps and sources.

The scripts and data that rebuild it are on GitHub in `docs/reports/2026-10-23_mission-report/` (pull request #13).

## New figures gathered for it
- ERS 15: 632 vetted good SatNOGS observations since 21 Oct 2020, by at least 96 stations; heard on 31.0% of vetted
  passes over the last 365 days (95% range 25.4–37.3%).
- Voyager 1: 172.69 au, 23 h 56 min one-way (JPL Horizons, 23 Oct 16:00 UT). Our free-space formula reproduces JPL's
  published Voyager design table to 0.01 dB.
- Zombie check re-run on 23 Oct: unchanged, 2 of 148 heard.

## Corrections relative to the 23 Oct "post-mission" draft
- The reception evidence is from SatNOGS volunteer stations, not Hannibal's own radio.
- Hannibal is not air-gapped: it uses public internet APIs (SatNOGS, N2YO, NASA/JPL).
- ERS 15 was documented as transmitting before this work (SatNOGS since 2020, Orbital Focus by 2014).
- Its battery-free design could not be confirmed from the sources checked; the 1.3 kHz tone could (Orbital Focus).
- An unrelated account-security incident is left out of the report.
