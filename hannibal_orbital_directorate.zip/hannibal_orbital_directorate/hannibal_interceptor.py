import sys
import time
import numpy as np
import datetime

# --- [ SOVIET BRUTALIST UI THEME ] ---
C_RED = "\033[91m"
C_AMBER = "\033[93m"
C_DIM = "\033[90m"
C_WHITE = "\033[97m"
C_RESET = "\033[0m"
C_BG_DARK = "\033[40m"

# ASCII gradient for the waterfall (low to high intensity)
# Using heavy block characters for that stark, mechanical aesthetic
WF_CHARS = [" ", "░", "▒", "▓", "█"]

class HannibalInterceptor:
    def __init__(self, tle_line1, tle_line2, nominal_freq):
        import os
        import ctypes
        
        local_dir = os.path.dirname(os.path.abspath(__file__))
        for dll_name in ["libusb-1.0.dll", "rtlsdr.dll", "librtlsdr.dll"]:
            dll_path = os.path.join(local_dir, dll_name)
            if os.path.exists(dll_path):
                try:
                    ctypes.CDLL(dll_path)
                except Exception:
                    pass

        from rtlsdr import RtlSdr
        from skyfield.api import load, EarthSatellite, wgs84
        
        self.sdr = RtlSdr()
        self.sdr.sample_rate = 2.048e6  # 2.048 MHz
        self.sdr.center_freq = nominal_freq
        self.sdr.gain = 'auto'
        
        # 2. ORBITAL: Skyfield Setup (Antwerp Ground Station)
        self.ts = load.timescale()
        self.station = wgs84.latlon(51.2194, 4.4025, elevation_m=10)
        self.satellite = EarthSatellite(tle_line1, tle_line2, 'TARGET-BIRD', self.ts)
        self.nominal_freq = nominal_freq
        self.c = 299792458.0
        
        # 3. STATE: Deadband & Recording
        self.current_freq = nominal_freq
        self.deadband_hz = 50
        self.recording = False
        self.iq_file = None

    def get_doppler_and_elevation(self):
        t = self.ts.now()
        difference = self.satellite - self.station
        topocentric = difference.at(t)
        alt, az, distance = topocentric.altaz()
        _, _, range_rate = topocentric.frame_latlon_and_rates(self.station)
        
        v_r = range_rate.m_per_s
        shifted_freq = self.nominal_freq * (1.0 - (v_r / self.c))
        return int(shifted_freq), v_r, alt.degrees

    def compute_fft_and_rssi(self, samples, bins=64):
        # Power Spectral Density (FFT)
        fft_data = np.fft.fftshift(np.fft.fft(samples))
        psd = 10 * np.log10(np.abs(fft_data)**2 + 1e-12) # Add epsilon to avoid log(0)
        
        # Calculate overall Signal Strength (RSSI / dBFS)
        rssi = np.mean(psd)
        
        # Decimate down to terminal width (bins)
        split_psd = np.array_split(psd, bins)
        waterfall_bins = [np.mean(chunk) for chunk in split_psd]
        return waterfall_bins, rssi

    def render_waterfall_row(self, bins, min_db=-60, max_db=20):
        row_str = ""
        for val in bins:
            # Normalize bin value to our 5-character array
            normalized = (val - min_db) / (max_db - min_db)
            idx = int(np.clip(normalized, 0, 1) * (len(WF_CHARS) - 1))
            
            # Colorize based on intensity (Dim -> Red -> Amber)
            char = WF_CHARS[idx]
            if idx >= 4:
                row_str += C_AMBER + char + C_RESET
            elif idx >= 2:
                row_str += C_RED + char + C_RESET
            else:
                row_str += C_DIM + char + C_RESET
        return row_str

    def run(self):
        print(f"{C_RED}{C_BG_DARK}[ HANNIBAL V9 // СИСТЕМА ПЕРЕХВАТА - ORBITAL INTERCEPT DAEMON ]{C_RESET}")
        print(f"{C_DIM}AOS THRESHOLD: 10.0° | DEADBAND: {self.deadband_hz} Hz | HARDWARE: RTL-SDR{C_RESET}\n")

        try:
            while True:
                # 1. ORBITAL MATH
                target_freq, v_r, elevation = self.get_doppler_and_elevation()
                
                # 2. DEADBAND FILTER (Only tune if shift is significant)
                if abs(target_freq - self.current_freq) >= self.deadband_hz:
                    self.sdr.center_freq = target_freq
                    self.current_freq = target_freq
                    tune_status = f"{C_AMBER}LOCKED{C_RESET}"
                else:
                    tune_status = f"{C_DIM}HOLD{C_RESET}"

                # 3. ACQUIRE SIGNAL (Read 8192 IQ samples)
                samples = self.sdr.read_samples(8192)
                
                # 4. SIGNAL PROCESSING
                wf_bins, rssi = self.compute_fft_and_rssi(samples, bins=60)
                wf_string = self.render_waterfall_row(wf_bins)

                # 5. ELEVATION TRIGGERED RECORDING
                if elevation > 10.0:
                    if not self.recording:
                        # [ARKHIPOV OVERRIDE] - Start recording
                        filename = f"intercept_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.iq"
                        self.iq_file = open(filename, 'wb')
                        self.recording = True
                    # Dump raw C8 bytes to disk
                    self.iq_file.write(samples.tobytes())
                    rec_status = f"{C_RED}[REC: ON]{C_RESET}"
                else:
                    if self.recording:
                        self.iq_file.close()
                        self.recording = False
                    rec_status = f"{C_DIM}[REC: OFF]{C_RESET}"

                # 6. RENDER HUD (Overwriting terminal line for smooth scroll)
                hud = (f"{C_WHITE}EL:{elevation:05.1f}° {C_DIM}|{C_RESET} "
                       f"{C_RED}V_R:{v_r:+07.1f}m/s {C_DIM}|{C_RESET} "
                       f"{C_AMBER}FREQ:{self.current_freq}Hz [{tune_status}] {C_DIM}|{C_RESET} "
                       f"RSSI:{rssi:05.1f}dB {rec_status}")
                
                sys.stdout.write(f"\r{hud}  {wf_string}")
                sys.stdout.flush()
                
                time.sleep(0.2) # 5 FPS waterfall

        except KeyboardInterrupt:
            print(f"\n{C_RED}[ KOMAROV FAIL-SAFE INITIATED: SHUTTING DOWN RF FRONTEND ]{C_RESET}")
            if self.iq_file:
                self.iq_file.close()
            self.sdr.close()

def screen_interceptor(ask, out, color):
    """Orbital Directorate hook for the RF Interceptor."""
    out(f"\n{C_RED}[ SATELLITE INTERCEPT TARGETING ]{C_RESET}")
    out("  [1] NOAA 15 (137.620 MHz)")
    out("  [2] NOAA 18 (137.9125 MHz)")
    out("  [3] NOAA 19 (137.100 MHz)")
    out("  [4] Custom TLE and Frequency")

    choice = ask("  Select target [1-4, Enter = back]: ", "").strip()

    line1 = '1 25338U 98030A   23315.52623351  .00000216  00000-0  10405-3 0  9997'
    line2 = '2 25338  98.7188 335.7924 0011504 220.1292 139.9157 14.26251216321946'
    freq = 137620000

    if choice == "2":
        line1 = '1 28654U 05018A   23316.42511111  .00000155  00000-0  85293-4 0  9999'
        line2 = '2 28654  99.0435 329.9535 0014385 187.8398 172.2618 14.12574044962450'
        freq = 137912500
    elif choice == "3":
        line1 = '1 33591U 09005A   23316.51234567  .00000123  00000-0  74123-4 0  9998'
        line2 = '2 33591  99.1234 321.1234 0013456 175.1234 185.1234 14.11111111111111'
        freq = 137100000
    elif choice == "4":
        line1 = ask("  TLE Line 1: ", "")
        line2 = ask("  TLE Line 2: ", "")
        try:
            freq = int(ask("  Nominal Frequency (Hz): ", "137620000"))
        except ValueError:
            out(f"{C_RED}[!] Invalid frequency. Aborting.{C_RESET}")
            return
    elif not choice:
        return

    out(f"\n{C_DIM}Initializing RTL-SDR frontend for {freq} Hz...{C_RESET}")
    try:
        daemon = HannibalInterceptor(line1, line2, nominal_freq=freq)
        daemon.run()
    except Exception as exc:
        out(f"{C_RED}[!] SDR Frontend Error: {exc}{C_RESET}")


if __name__ == "__main__":
    # Example TLE for NOAA 15 (Replace with ERS-15 or target bird)
    line1 = '1 25338U 98030A   23315.52623351  .00000216  00000-0  10405-3 0  9997'
    line2 = '2 25338  98.7188 335.7924 0011504 220.1292 139.9157 14.26251216321946'
    
    # 137.620 MHz nominal frequency
    daemon = HannibalInterceptor(line1, line2, nominal_freq=137620000)
    daemon.run()