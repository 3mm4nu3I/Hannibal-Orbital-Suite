Set-Content -Path "apply_dll_fix.py" -Value '
import re
from pathlib import Path
import shutil

p = Path("hannibal_interceptor.py")
if not p.exists():
    print("[-] hannibal_interceptor.py not found!")
    exit(1)

shutil.copy2(p, p.with_suffix(".py.bak_dll"))
text = p.read_text(encoding="utf-8")

old_pattern = r"(    def __init__\(self, tle_line1, tle_line2, nominal_freq\):.*?self\.sdr = RtlSdr\(\))"

new_init = """    def __init__(self, tle_line1, tle_line2, nominal_freq):
        import os
        import ctypes
        
        local_dir = os.path.dirname(os.path.abspath(__file__))
        for dll_name in ["libusb-1.0.dll", "rtlsdr.dll", "librtlsdr.dll"]:
            dll_path = os.path.join(local_dir, dll_name)
            if os.path.exists(dll_path):
                try:
                    ctypes.CDLL(dll_path)
                except Exception:
                    pass

        from rtlsdr import RtlSdr
        from skyfield.api import load, EarthSatellite, wgs84
        
        self.sdr = RtlSdr()"""

new_text, count = re.subn(old_pattern, new_init, text, flags=re.DOTALL)
if count > 0:
    p.write_text(new_text, encoding="utf-8")
    print("[+] Hotfix applied successfully! hannibal_interceptor.py now forces local DLL loading.")
else:
    print("[-] Pattern match failed. Please verify your hannibal_interceptor.py structure.")
'
python apply_dll_fix.py