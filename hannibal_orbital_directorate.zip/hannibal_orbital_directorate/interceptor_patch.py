import shutil
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

INTERCEPTOR_PATH = BASE_DIR / "hannibal_interceptor.py"
ORBITAL_PATH = BASE_DIR / "hannibal_orbital.py"
TERMINAL_PATH = BASE_DIR / "hannibal_terminal.py"

# --- 1. Payload for hannibal_interceptor.py ---
INTERCEPTOR_HOOK = """

def screen_interceptor(ask, out, color):
    \"\"\"Orbital Directorate hook for the RF Interceptor.\"\"\"
    out(f"\\n{C_RED}[ SATELLITE INTERCEPT TARGETING ]{C_RESET}")
    out("  [1] NOAA 15 (137.620 MHz)")
    out("  [2] NOAA 18 (137.9125 MHz)")
    out("  [3] NOAA 19 (137.100 MHz)")
    out("  [4] Custom TLE and Frequency")

    choice = ask("  Select target [1-4, Enter = back]: ", "").strip()

    line1 = '1 25338U 98030A   23315.52623351  .00000216  00000-0  10405-3 0  9997'
    line2 = '2 25338  98.7188 335.7924 0011504 220.1292 139.9157 14.26251216321946'
    freq = 137620000

    if choice == "2":
        line1 = '1 28654U 05018A   23316.42511111  .00000155  00000-0  85293-4 0  9999'
        line2 = '2 28654  99.0435 329.9535 0014385 187.8398 172.2618 14.12574044962450'
        freq = 137912500
    elif choice == "3":
        line1 = '1 33591U 09005A   23316.51234567  .00000123  00000-0  74123-4 0  9998'
        line2 = '2 33591  99.1234 321.1234 0013456 175.1234 185.1234 14.11111111111111'
        freq = 137100000
    elif choice == "4":
        line1 = ask("  TLE Line 1: ", "")
        line2 = ask("  TLE Line 2: ", "")
        try:
            freq = int(ask("  Nominal Frequency (Hz): ", "137620000"))
        except ValueError:
            out(f"{C_RED}[!] Invalid frequency. Aborting.{C_RESET}")
            return
    elif not choice:
        return

    out(f"\\n{C_DIM}Initializing RTL-SDR frontend for {freq} Hz...{C_RESET}")
    try:
        daemon = HannibalInterceptor(line1, line2, nominal_freq=freq)
        daemon.run()
    except Exception as exc:
        out(f"{C_RED}[!] SDR Frontend Error: {exc}{C_RESET}")
"""

# --- 2. Payload for hannibal_orbital.py ---
ORBITAL_TARGET = "def run_menu(input_fn=None, print_fn=print, color=None, animate=False, logins=None, home=None, secret_fn=None):"
ORBITAL_PATCH = """# --- RF Interceptor (added via patch_interceptor.py) --------------------------------------------------
try:
    import hannibal_interceptor
    MENU.insert(next((i for i, m in enumerate(MENU) if m[0] == "E"), len(MENU)),
                ("X", "RF Interceptor         live SDR waterfall and Doppler tuning (RTL-SDR)",
                 hannibal_interceptor.screen_interceptor))
except Exception:  # noqa: BLE001
    hannibal_interceptor = None


""" + ORBITAL_TARGET

# --- 3. Payloads for hannibal_terminal.py ---
TERM_FUNC_TARGET = "def sat_ops_menu():"
TERM_FUNC_PATCH = """def sat_interceptor_menu():
    \"\"\"Blocking SDR waterfall hook -- matches [T] chat and [V] orbital menu.\"\"\"
    try:
        clear_screen()
    except Exception:
        pass
    try:
        import hannibal_interceptor
        hannibal_interceptor.screen_interceptor(
            ask=lambda prompt, default="": (input(prompt).strip() or default),
            out=print,
            color=True
        )
    except Exception as exc:
        print(f" {RED}RF Interceptor unavailable:{RESET} {exc}")
        time.sleep(1.5)


""" + TERM_FUNC_TARGET

TERM_FOOTER_TARGET = "| [V] Ops | [Y] Speed | [H] Audit {RESET}\")"
TERM_FOOTER_PATCH = "| [V] Ops | [X] SDR | [Y] Speed | [H] Audit {RESET}\")"

TERM_KEYS_TARGET = "elif key.upper() in MARKETS or key in ['w', 'k', 'i', 'c', 'p', 'h', 'g', 'm', 's', 't', 'y', 'l', 'b', 'v']:"
TERM_KEYS_PATCH = "elif key.upper() in MARKETS or key in ['w', 'k', 'i', 'c', 'p', 'h', 'g', 'm', 's', 't', 'y', 'l', 'b', 'v', 'x']:"

TERM_HANDLER_TARGET = """            elif key_pressed == 'V':  # [ORBITAL-PATCH:handler_V]"""
TERM_HANDLER_PATCH = """            elif key_pressed == 'X':  # [INTERCEPTOR-PATCH:handler_X]
                sat_interceptor_menu()
            elif key_pressed == 'V':  # [ORBITAL-PATCH:handler_V]"""


def backup_file(path: Path):
    bak = path.with_suffix(path.suffix + ".bak")
    if not bak.exists():
        shutil.copy2(path, bak)
        print(f"  [+] Backup created: {bak.name}")


def patch_interceptor():
    if not INTERCEPTOR_PATH.exists():
        print(f"  [!] Missing {INTERCEPTOR_PATH.name}")
        return
    text = INTERCEPTOR_PATH.read_text(encoding="utf-8")
    if "def screen_interceptor(" in text:
        print(f"  [~] {INTERCEPTOR_PATH.name} already patched.")
        return
    backup_file(INTERCEPTOR_PATH)
    marker = 'if __name__ == "__main__":'
    if marker in text:
        text = text.replace(marker, INTERCEPTOR_HOOK.lstrip() + "\n\n" + marker, 1)
    else:
        text += INTERCEPTOR_HOOK
    INTERCEPTOR_PATH.write_text(text, encoding="utf-8")
    print(f"  [+] Patched {INTERCEPTOR_PATH.name}")


def patch_orbital():
    if not ORBITAL_PATH.exists():
        print(f"  [!] Missing {ORBITAL_PATH.name}")
        return
    text = ORBITAL_PATH.read_text(encoding="utf-8")
    if "hannibal_interceptor" in text:
        print(f"  [~] {ORBITAL_PATH.name} already patched.")
        return
    if ORBITAL_TARGET not in text:
        print(f"  [!] Could not find injection anchor in {ORBITAL_PATH.name}")
        return
    backup_file(ORBITAL_PATH)
    text = text.replace(ORBITAL_TARGET, ORBITAL_PATCH, 1)
    ORBITAL_PATH.write_text(text, encoding="utf-8")
    print(f"  [+] Patched {ORBITAL_PATH.name}")


def patch_terminal():
    if not TERMINAL_PATH.exists():
        print(f"  [!] Missing {TERMINAL_PATH.name}")
        return
    text = TERMINAL_PATH.read_text(encoding="utf-8")
    if "sat_interceptor_menu" in text:
        print(f"  [~] {TERMINAL_PATH.name} already patched.")
        return

    anchors = [
        (TERM_FUNC_TARGET, TERM_FUNC_PATCH),
        (TERM_FOOTER_TARGET, TERM_FOOTER_PATCH),
        (TERM_KEYS_TARGET, TERM_KEYS_PATCH),
        (TERM_HANDLER_TARGET, TERM_HANDLER_PATCH),
    ]
    for target, _ in anchors:
        if target not in text:
            print(f"  [!] Could not find anchor in {TERMINAL_PATH.name}: {target[:45]}...")
            return

    backup_file(TERMINAL_PATH)
    for target, replacement in anchors:
        text = text.replace(target, replacement, 1)
    TERMINAL_PATH.write_text(text, encoding="utf-8")
    print(f"  [+] Patched {TERMINAL_PATH.name}")


if __name__ == "__main__":
    print("[ PROJECT HANNIBAL // AUTOMATED INTERCEPTOR FUSION ]")
    patch_interceptor()
    patch_orbital()
    patch_terminal()
    print("[ COMPLETE ]")